using UnityEngine;

public class PlayerHealth : MonoBehaviour, IDamageable
{
    [SerializeField]
    private PlayerStats PS;
    private PlayerAnimations playerAnimations;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        playerAnimations = GetComponent<PlayerAnimations>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            TakeDamage(1f);
        }
    }

    public void TakeDamage(float amount)
    {

        PS.health -= amount;
        if(PS.health <= 0)
        {
            PlayerDead();
        }

    }

    public void PlayerDead()
    {
        playerAnimations.SetDeadAnimation();
    }

}
