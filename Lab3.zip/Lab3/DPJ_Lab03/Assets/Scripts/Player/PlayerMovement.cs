using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("Config")]
    [SerializeField]
    private float speed;

    private ActionMap actions;
    private Rigidbody2D body2D;
    private Animator anim;
    private PlayerAnimations playerAnimations;
    private Player player;

    private void Awake()
    {
        actions = new ActionMap();
        body2D = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        playerAnimations = GetComponent<PlayerAnimations>();
        player = GetComponent<Player>();
    }

    private void OnEnable()
    {
        actions.Enable();
    }

    private void OnDisable()
    {
        actions.Disable();
    }

    private Vector2 moveDirection;
    private void ReadMovement()
    {
        moveDirection = actions.Movement.Move.ReadValue<Vector2>().normalized;

        playerAnimations.SetMoveBoolTransition(false);  
        if(moveDirection == Vector2.zero) return;

        playerAnimations.SetMoveBoolTransition(true);
        playerAnimations.SetMoveAnimation(moveDirection);
        
    }

    private void Move()
    {
        if(player.stats.health <= 0)
        {
            return;
        }

        body2D.MovePosition(body2D.position + moveDirection * (speed * Time.fixedDeltaTime));
    }

    private void FixedUpdate()
    {
        Move();
    }

    private void Update()
    {
        ReadMovement();
    }
}