using UnityEngine;

public class Player : MonoBehaviour
{
    [Header("Config")]
    [SerializeField]
    private PlayerStats playerStats;
    public PlayerStats stats => playerStats;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
