using UnityEngine;

public interface IDamageable
{
    // Interfaces store methods and are accessible by other classes because they use "interface"
    // As interfaces servem para guardar metodos e s�o acessiveis por outras classes devido a usarem "interface"
    void TakeDamage(float amount);
}
